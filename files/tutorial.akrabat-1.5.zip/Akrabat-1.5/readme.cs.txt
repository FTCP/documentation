Nette Framework example "Akrabat 1.5"
-------------------------------------

Klasický Zend Framework Tutorial přepsaný pro Nette.

Příklad demonstruje velmi důležitý rys Nette Frameworku: v rámci aplikace a to včetně šablon
se nepoužívají URL. Ty jsou záležitostí routeru a mohou se kdykoliv měnit. Cílem odkazu je vždy
kombinace "Presenter:action" nebo "Presenter:signal!".

Pro přihlášení použijte
username: demo
password: xxx

Zdroj: http://akrabat.com/zend-framework-tutorial/ (Getting Started with the Zend Framework 1.5)
