Nette Framework example "Akrabat 1.5"
-------------------------------------

Classic Zend Framework Tutorial rewritten for Nette.

The example shows an important feature of the Nette Framework: the URLs are
not used inside the application including the templates. The URLs are in
responsibility of the router and can be changed anytime. The target of a link
is always a combination "Presenter:action" or "Presenter:signal!".

To sign in:
username: demo
password: xxx

Source: http://akrabat.com/zend-framework-tutorial/ (Getting Started with the Zend Framework 1.5)
